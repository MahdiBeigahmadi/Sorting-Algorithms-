// a4_sort_implementations.h

/////////////////////////////////////////////////////////////////////////
//
// Student Info
// ------------
//
// Name : <Mahdi Beigahmadi>
// St.# : <301570853>
// Email: <mba188@sfu.ca>
//
//
// Statement of Originality
// ------------------------
//
// All the code and comments below are my own original work. For any non-
// original work, I have provided citations in the comments with enough
// detail so that someone can see the exact source and extent of the
// borrowed work.
//
// In addition, I have not shared this work with anyone else, and I have
// not seen solutions from other students, tutors, websites, books,
// etc.
//
/////////////////////////////////////////////////////////////////////////

#pragma once

#include "a4_base.h"

using namespace std;

ulong numComps = 0;

// I copied bubbleSort from the
// example you described on assignment page :|

// it repeatedly swaps adjacent elements in a list if they are in the wrong order,
//  effectively 'bubbling' the largest unsorted element
// to its correct position in each pass through the list.

template <typename T>
Sort_stats bubble_sort(vector<T> &v)
{
    clock_t start = clock();

    for (int i = 0; i < v.size(); i++)
    {
        for (int j = 0; j <
                        v.size() - 1;
             j++)
        {
            numComps++;
            if (v[j] > v[j + 1])
            {
                T temp = v[j];
                v[j] = v[j + 1];
                v[j + 1] = temp;
            }
        }
    }

    clock_t end = clock();

    double elapsed_cpu_time_sec =
        double(end - start) / CLOCKS_PER_SEC;
    return Sort_stats{"Bubble sort",
                      v.size(),
                      numComps,
                      elapsed_cpu_time_sec};
}
// it  builds a sorted array one element at
// a time by repeatedly taking an unsorted element
// and inserting it into its correct
// position in the sorted part of the array.
// help source for writing the code: ChatGPT
template <typename T>
Sort_stats insertion_sort(vector<T> &v)
{
    clock_t start = clock();
    for (int i = 1; i < v.size(); i++)
    {
        T key = v[i];
        int j = i - 1;
        while (j >= 0 && v[j] > key)
        {
            numComps++;
            v[j + 1] = v[j];
            j = j - 1;
        }
        v[j + 1] = key;
    }
    clock_t end = clock();
    double elapsed_cpu_time_sec =
        double(end - start) / CLOCKS_PER_SEC;
    return Sort_stats{"Insertion sort",
                      v.size(),
                      numComps,
                      elapsed_cpu_time_sec};
}
// it repeatedly finds the smallest (or largest) element
// from the unsorted part of the list and moves it to the beginning,
// effectively selecting the next element in the sorted order in each iteration.
//  help source for writing the code: ChatGPT
template <typename T>
Sort_stats selection_sort(vector<T> &v)
{
    clock_t start = clock();

    for (int i = 0; i < v.size() - 1; i++)
    {
        int minIndex = i;
        for (int j = i + 1; j < v.size(); j++)
        {
            numComps++;
            if (v[j] < v[minIndex])
            {
                minIndex = j;
            }
        }
        if (minIndex != i)
        {
            swap(v[i], v[minIndex]);
        }
    }

    clock_t end = clock();
    double elapsed_cpu_time_sec =
        double(end - start) / CLOCKS_PER_SEC;
    return Sort_stats{"Selection sort",
                      v.size(), numComps,
                      elapsed_cpu_time_sec};
}

// first sorts elements far apart from each other and
// progressively reduces the gap between elements to be compared,
// leading to an efficient sorting of the entire list.
// help source for writing the code: ChatGPT
template <typename T>
Sort_stats shell_sort(vector<T> &v)
{
    clock_t start = clock();
    int n = static_cast<int>(v.size());
    for (int gap = n / 2; gap > 0; gap /= 2)
    {
        for (int i = gap; i < n; i += 1)
        {
            T temp = v[i];
            int j;
            for (j = i; j >= gap &&
                        v[j - gap] > temp;
                 j -= gap)
            {
                numComps++;
                v[j] = v[j - gap];
            }
            v[j] = temp;
        }
    }
    clock_t end = clock();
    double elapsed_cpu_time_sec =
        double(end - start) / CLOCKS_PER_SEC;
    return Sort_stats{"Shell sort", v.size(),
                      numComps, elapsed_cpu_time_sec};
}
// it repeatedly splits a list into halves until
// each half contains a single element,
// then merges these smaller lists in
// a sorted manner to form a larger sorted list
//  help source for writing the code: ChatGPT

template <typename T>
void merge(vector<T> &v, int left, int middle, int right)
{
    vector<T> temp(right - left + 1);
    int i = left, j = middle + 1, k = 0;

    while (i <= middle && j <= right)
    {
        numComps++;
        if (v[i] <= v[j])
            temp[k++] = v[i++];
        else
            temp[k++] = v[j++];
    }

    while (i <= middle)
        temp[k++] = v[i++];

    while (j <= right)
        temp[k++] = v[j++];

    for (i = left, k = 0;
         i <= right; ++i, ++k)
        v[i] = temp[k];
}
// help source for writing the code: ChatGPT
template <typename T>
void mergeSortRecursive(vector<T> &v,
                        unsigned int left, unsigned int right)
{
    if (left < right)
    {
        unsigned int middle = left + (right - left) / 2;
        mergeSortRecursive(v, left, middle);
        mergeSortRecursive(v, middle + 1, right);
        merge(v, left, middle, right);
    }
}
template <typename T>
Sort_stats merge_sort(vector<T> &v)
{
    clock_t start = clock();
    mergeSortRecursive(v, 0, v.size() - 1);
    clock_t end = clock();
    double elapsed_cpu_time_sec =
        double(end - start) / CLOCKS_PER_SEC;
    return Sort_stats{"Merge sort",
                      v.size(), numComps,
                      elapsed_cpu_time_sec};
}

double helperTimer = 0;
template <typename T>
int partitionQuick(vector<T> &v, int low, int high)
{
    T pivot = v[high];
    int i = (low - 1);
    for (int j = low; j <= high - 1; j++)
    {
        numComps++;
        if (v[j] < pivot)
        {
            i++;
            swap(v[i], v[j]);
        }
    }
    swap(v[i + 1], v[high]);
    return (i + 1);
}

template <typename T>
void quickSortRecursive(vector<T> &v, int low, int high)
{
    if (low < high)
    {
        int pi = partitionQuick(v, low, high);
        quickSortRecursive(v, low, pi - 1);
        quickSortRecursive(v, pi + 1, high);
    }
}
// it selects a 'pivot' element and partitions the array into two halves:
// elements less than the pivot and elements greater than it,
//  then recursively applies the same process to the two halves.
//  help source for writing the code: ChatGPT
template <typename T>
Sort_stats quick_sort(vector<T> &v)
{
    clock_t start = clock();
    quickSortRecursive(v, 0, v.size() - 1);
    clock_t end = clock();
    double elapsed_cpu_time_sec =
        double(end - start) / CLOCKS_PER_SEC;
    return Sort_stats{"Quick sort",
                      v.size(), numComps,
                      elapsed_cpu_time_sec};
}

// help source for writing the code: ChatGPT
double iQuickHelper = 0;

template <typename T>
void insertionSort(vector<T> &v, int start, int end)
{
    for (int i = start + 1; i <= end; ++i)
    {
        T key = v[i];
        int j = i - 1;

        while (j >= start && v[j] > key)
        {
            numComps++;
            v[j + 1] = v[j];
            j = j - 1;
        }
        v[j + 1] = key;
    }
}

template <typename T>
int partition(vector<T> &v, int low, int high)
{
    clock_t start = clock();
    T pivot = v[high];
    int i = (low - 1);

    for (int j = low; j <= high - 1; j++)
    {
        numComps++;
        if (v[j] < pivot)
        {
            i++;
            swap(v[i], v[j]);
        }
    }
    swap(v[i + 1], v[high]);
    clock_t end = clock();
    double elapsed_cpu_time_sec =
        double(end - start) / CLOCKS_PER_SEC;
    iQuickHelper = elapsed_cpu_time_sec;
    return (i + 1);
}

template <typename T>
void iQuickSortRecursive(vector<T> &v,
                         int low, int high, int threshold)
{
    while (low < high)
    {
        if (high - low < threshold)
        {
            insertionSort(v, low, high);
            break;
        }
        else
        {
            int pi = partition(v, low, high);

            if (pi - low < high - pi)
            {
                iQuickSortRecursive(v,
                                    low, pi - 1, threshold);
                low = pi + 1;
            }
            else
            {
                iQuickSortRecursive(v,
                                    pi + 1, high, threshold);
                high = pi - 1;
            }
        }
    }
}
// it is the optimized sorting algorithm of quick sort
template <typename T>
Sort_stats iquick_sort(vector<T> &v)
{
    long int threshold = 10000000;
    iQuickSortRecursive(v, 0, v.size() - 1, threshold);
    return Sort_stats{"iQuick sort",
                      v.size(),
                      numComps,
                      iQuickHelper};
}
// help source for writing the code: ChatGPT
double timerHeap = 0;
template <typename T>
void heapAdjust(vector<T> &v, int size, int root)
{
    clock_t start = clock();
    int largest = root;
    int left = 2 * root + 1;
    int right = 2 * root + 2;

    if (left < size && v[left] > v[largest])
        largest = left;
    numComps++;

    if (right < size && v[right] > v[largest])
        largest = right;
    numComps++;
    if (largest != root)
    {
        swap(v[root], v[largest]);
        heapAdjust(v, size, largest);
    }
    clock_t end = clock();
    double elapsed_cpu_time_sec =
        double(end - start) / CLOCKS_PER_SEC;
    timerHeap = elapsed_cpu_time_sec;
}
// builds a heap from the given data,
// then repeatedly removes the largest element from the heap
// and reconstructs the heap,
// effectively sorting the elements in ascending order.
// help source for writing the code: ChatGPT
template <typename T>
Sort_stats priority_queue_sort(vector<T> &v)
{
    int num = v.size();

    for (int i = num / 2 - 1; i >= 0; i--)
        heapAdjust(v, num, i);

    for (int i = num - 1; i > 0; i--)
    {

        swap(v[0], v[i]);

        heapAdjust(v, i, 0);
    }
    return Sort_stats{"Priority Queue sort",
                      v.size(),
                      numComps,
                      timerHeap};
}

template <typename T>
bool is_sorted(vector<T> &v)
{
    for (size_t i = 1; i < v.size(); ++i)
    {
        if (v[i - 1] > v[i])
        {
            return false;
        }
    }
    return true;
}

vector<int> rand_vec(int size, int min, int max)
{
    vector<int> vec(size);
    srand(static_cast<unsigned int>(time(nullptr)));
    for (int i = 0; i < size; ++i)
    {
        vec[i] = min + rand() % (max - min + 1);
    }
    return vec;
}
